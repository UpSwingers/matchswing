import logo from './output-onlinepngtools.png';
import logo2 from './op.jpg';
import './App.css';
import lg from './lg.jpeg';
import b from './b.png';

function App() {
  return (

    <div className="App">

      <nav>
        <a href="https://reactjs.org" className='navbart'><b>MatchSwingers</b></a>
        <a href="https://reactjs.org" className='navbari'>Create</a>
        <a href="https://reactjs.org" className='navbari'>Council</a>
        <a href="https://reactjs.org" className='navbari'>Forum</a>
        <a href="https://reactjs.org" className='navbari'>About</a>
        <a href="#Log" className='navbari'>Sign In</a>

      </nav>
      <img src={lg} className="im" align="right" alt="logo" />
      <div id="Log" className="Body">
        <div className="main">
          <input type="checkbox" id="chk" aria-hidden="true" />

          <div className="signup">
            <form>
              <label htmlFor="chk" aria-hidden="true">Sign Up</label>
              <input type="text" name="txt" placeholder="User name" required="" />
              <input type="email" name="email" placeholder="Email" required="" />
              <input type="password" name="pswd" placeholder="Password" required="" />
              <button>Sign Up</button>
            </form>
          </div>

          <div className="login">
            <form>
              <label htmlFor="chk" aria-hidden="true">Sign In</label>
              <input type="email" name="email" placeholder="Email" required="" />
              <input type="password" name="pswd" placeholder="Password" required="" />
              <button>Sign In</button>
            </form>
          </div>
        </div>
      </div>
      <p className="g">MatchSwingers provides a decentralised model for cricket content to be consumed and distributed. It aims to create a more loyal fan base by giving them incentives in the form of NFTs.</p>
      <img src={b} className="cd" alt="logo" />

      <div className="bottom-navbar">
        <div className="bottom-navbar-link-container">
          <a href="#" className="bottom-navbar-link">Link 1</a>
          <a href="#" className="bottom-navbar-link">Link 2</a>
          <a href="#" className="bottom-navbar-link">Link 3</a>
          <a href="#" className="bottom-navbar-link">Link 4</a>
          <a href="#" className="bottom-navbar-link">Link 4</a>
          <a href="#" className="bottom-navbar-link">Link 4</a>
          <a href="#" className="bottom-navbar-link">Link 4</a>
          <a href="#" className="bottom-navbar-link">Link 4</a>

        </div>
      </div>
    </div>
  );
}

export default App;
